package com.example.MCore.controller;

public class CatalogoControllerTest {
    
}
